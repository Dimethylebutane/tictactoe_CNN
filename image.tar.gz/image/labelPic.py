import matplotlib.pyplot as plt
import json
import cv2
import numpy as np
from scipy.signal import argrelextrema
import os

N = os.listdir(".")
N = [ n for n in N if n[0] == 'M']

print(len(N), ":", N)

D = {}
try:
    D = json.load(open("label.json"))
except:
    print("no previous data, from start")
print(D)

global DCi
DCi = 0
def draw_circle(event,x,y,flags,param):
    global DCi
    param, ri = param
    if event == cv2.EVENT_LBUTTONDBLCLK:
        if D[param][0][0] == -1:
            DCi = 0
        elif D[param][1][0] == -1:
            DCi = 1
        D[param][DCi] = (x, y)
        DCi = (DCi+1)%2

def saveDict(D):
    print(D)
    try:
        json.dump(D, open("label.json", "wt"))
    except:
        print("Unable to write to file")

    exit()

for img_path in N:
    if img_path not in D:
        D[img_path] = [[-1, -1], [-1, -1]]

    rawimg = cv2.imread(img_path)

    global img
    img = rawimg.copy()
    cv2.imshow("image", img)
    cv2.setMouseCallback('image',draw_circle, param=(img_path, rawimg))
    while True:
        img = rawimg.copy()
        cv2.rectangle(img, D[img_path][0], D[img_path][1], (255, 0, 0), 3)
        p = D[img_path][DCi]
        cv2.circle(img,(p[0], p[1]), 5,(0,255,0),-1)

        k = cv2.waitKey(1)
        cv2.imshow('image',img)
        # Press 'q' to exit the loop
        if k == ord('n'):
            break
        if k == ord('q'):
            saveDict(D)

saveDict(D)


