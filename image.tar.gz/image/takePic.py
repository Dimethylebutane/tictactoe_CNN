import matplotlib.pyplot as plt
import cv2
import numpy as np
from scipy.signal import argrelextrema
import os

N = os.listdir(".")
N = [ int(n[1:-4]) for n in N if n[0] == 'M']
if len(N) == 0:
    N = 0
else:
    N = max(N) + 1

print("writing from file", N)

# Open the default camera
cam = cv2.VideoCapture(0)

# Get the default frame width and height
frame_width = int(cam.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cam.get(cv2.CAP_PROP_FRAME_HEIGHT))

while True:
    ret, frame = cam.read()
    if not ret:
        print("error aqc img, exiting...")
        break

    cv2.imshow('Camera', frame)

    k = cv2.waitKey(1)
    # Press 'q' to exit the loop
    if k == ord('q'):
        break
    if k == ord('s'):
        cv2.imwrite("M" + str(N) + ".jpg", frame)
        print(N)
        N = N + 1

# Release the capture and writer objects
cam.release()
cv2.destroyAllWindows()
